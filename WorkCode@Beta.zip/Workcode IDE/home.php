<!--
���� ������ Nick
�������������:
Sololearn Q&A
Toster.ru
Mozilla
Apple.Inc
Google-->
<!doctype html>
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Pangolin" rel="stylesheet">
<style>
iframe {
border-style: none;
}
.footer {
color: #c0c0c0;
}
footer {
background-color: #696969;
}
#header {
text-align:center;
}
a.hide {
display:none;
}
kbd {
background-color: #ccc;
border-radius: 3px;
padding: 0 4px;
}
h1.color {
background: #696969;
color: #F5F5F5;
}
body {
background-color: #F5F5F5;
user-select: none;
    -webkit-user-select: none:
    -moz-user-select: none;
    -khtml-user-select: none;
}
</style>
<script>var nick = function() {alert('??????? Nick ?ozilla');}</script>
<menu>
<menuitem icon="vimeo.ico" onclick="nick();" label="�? ? Mozilla">
</menu>
<link rel="SHORTCUT ICON" href="vimeo.ico" type="image/x-icon">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="Nick">
<title>???title>
<script>
var message = "Error";
function click(e) {
if (document.all) {
if (event.button == 2) {
alert(message);
return false; }
}
if (document.layers) {
if (e.which == 3) {
alert(message);
return false; }
}
}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);}
document.onmousedown=click;
document.oncontextmenu=function(e) {return false};
var logout = function() {
window.location.href='index.html';
}
</script>
</head>
<body onunload="logout();alert('U ?????" onselectstart="return false;" oncopy="return false;">
<div id="header">
<!--<header>-->
<h1>
����� ����������!!!
</h1>
<!--</header>-->
<!--Search-->
<form><input class="place_for_search" type="text" id="text-to-find" value="" placeholder="�?">
<input class="button_for_turn_back" type="button" onclick="javascript: FindOnPage('text-to-find', false); return false;" value="? title="Cancell">
<input class="button_for_search" type="submit" onclick="javascript: FindOnPage('text-to-find', true); return false;" value="Go" title="GO"><script src="js.js"></script></form> </div>
<div align="left">
<a ><iframe src="frame1.html"></iframe></a><iframe src="frame4.html" scrolling="no" seamless width="900"></iframe><br>
<a><iframe src="frame2.html"></iframe></a><br>
<a name="developer">
<iframe src="frame3.html"></iframe></a>
</div>
</body>
</html>