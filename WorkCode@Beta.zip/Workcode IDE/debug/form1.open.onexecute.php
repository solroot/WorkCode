<?php c("openDlg1")->execute();
if (c("openDlg1")->files == "") {
    MessageBox("�������� ����", "WorkCode");
} else {
    $open = c("openDlg1")->fileName;
    $fp = fopen($open, "r+");
    c("memo1")->loadFromFile($open);
    fclose($fp);
}
