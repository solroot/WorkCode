<?php c("memo1")->text = $files;
