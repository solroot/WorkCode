<?php c("label2")->caption = c("memo1")->__LINE__;
