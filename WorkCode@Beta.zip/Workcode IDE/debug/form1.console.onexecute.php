<?php if (c("Form1")->h == 424) {
c("Form1")->h = 435;
c("shape1")->visible = true;
c("label2")->visible = true;
c("link1")->visible = false;
}
else if (c("Form1")->h == 435) {
c("Form1")->h = 424;
c("shape1")->visible = false;
c("label2")->visible = false;
c("link1")->visible = true;
}
