<?php $dir = system("dir");
alert($dir);
