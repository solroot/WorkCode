<?php c("saveDlg1")->execute();
global $file;
if (c("saveDlg1")->fileName == "") {
MessageBox("�������� ���� ����", "WorkCode IDE");
} else {
$file = c("saveDlg1")->fileName;
$input = c("memo1")->text;
$define = "#include <stdio.h>";
$define2 = "#include <locale.h>";
$define3 = "#define begin {";
$define5 = "#define end }";
$define6 ="#define num int";
$define7 = "#define str char";
$define8 = "#define println printf";
$define9 = "#define input scanf";
$define10 = "#define main void main()";
$fp = fopen($file, "a");
$text = "$define\n$define2\n$define3\n$define4\n$define5\n$define6\n$define7\n$define8\n$define9\n$define10\n$input\n";
$test = fwrite($fp, $text);
if ($test) MessageBox("�����.", "IDE");
else MessageBox("������", "IDE");
fclose($fp);
}
